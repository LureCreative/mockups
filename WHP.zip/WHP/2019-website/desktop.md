---
title: "Desktop"
layout: desktop
mockups:
  -
    image: "dekstop-1.jpg"
    title: "Home Page"
  -
    image: "dekstop-2.jpg"
    title: "Home Page 2"
---
